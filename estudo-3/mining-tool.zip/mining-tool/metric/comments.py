import re

bot = "codacy-bot|Codacy|SonarQube analysis"


def compute_comments(gl_discussions):
    total_comments = 0
    general_comments = 0
    inline_comments = 0
    effective_comments = 0

    for discussion in gl_discussions:
        for note in discussion.attributes['notes']:
            test_bot = re.findall(bot, note['body'])

            if note['system']:
                if note['type'] == 'DiffNote':
                    effective_comments += 1
            elif not test_bot:
                total_comments += 1

                if note['type'] == 'DiscussionNote' or note['type'] is None:
                    general_comments += 1

                elif note['type'] == 'DiffNote':
                    inline_comments += 1

    return {
        'total_comments': total_comments,
        'general_comments': general_comments,
        'inline_comments': inline_comments,
        'effective_comments': effective_comments
    }
