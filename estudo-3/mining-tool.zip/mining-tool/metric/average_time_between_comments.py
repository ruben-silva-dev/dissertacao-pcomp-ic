import re
from datetime import datetime

datetime_format = '%Y-%m-%dT%H:%M:%S.%f%z'
bot = "codacy-bot|Codacy|SonarQube analysis"


def compute_atbc(gl_notes):
    notes = []

    for note in gl_notes:
        test_bot = re.findall(bot, note.body)
        if not note.system and not test_bot:
            notes.append(note)

    if len(notes) > 1:
        intervals, i = [], 1

        notes.sort(key=note_sort)
        while i < len(notes):
            start_datetime = datetime.strptime(notes[i-1].created_at, datetime_format)
            end_datetime = datetime.strptime(notes[i].created_at, datetime_format)
            intervals.append((end_datetime - start_datetime).total_seconds())
            i += 1

        return sum(intervals) / len(intervals)

    return 0


def note_sort(note):
    return note.created_at
