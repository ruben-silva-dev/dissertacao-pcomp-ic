import sys
from datetime import datetime

datetime_format = '%Y-%m-%dT%H:%M:%S.%f%z'


def compute_rt(gl_merge_request):
    if gl_merge_request.created_at is not None \
            and gl_merge_request.merged_at is not None:
        start_datetime = datetime.strptime(gl_merge_request.created_at, datetime_format)
        end_datetime = datetime.strptime(gl_merge_request.merged_at, datetime_format)
        return (end_datetime - start_datetime).total_seconds()

    return sys.float_info.max / 3
