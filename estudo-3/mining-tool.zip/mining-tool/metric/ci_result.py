import re


def compute_cr(gl_project, gl_pipelines):
    run = 0
    fail = 0
    error = 0
    skipped = 0

    for pipeline in gl_pipelines:
        for job in gl_project.pipelines.get(pipeline.id).jobs.list(get_all=True):
            if job.status == 'success' or job.status == 'failed':
                job_trace = gl_project.jobs.get(job.id).trace().decode("utf-8")

                run_matches = re.findall("Tests run: \\d+", job_trace)
                fail_matches = re.findall("Failures: \\d+", job_trace)
                error_matches = re.findall("Errors: \\d+", job_trace)
                skipped_matches = re.findall("Skipped: \\d+", job_trace)

                if run_matches:
                    run += int(re.search("\\d+", run_matches[len(run_matches) - 1]).group())
                if fail_matches:
                    fail += int(re.search("\\d+", fail_matches[len(fail_matches) - 1]).group())
                if error_matches:
                    error += int(re.search("\\d+", error_matches[len(error_matches) - 1]).group())
                if skipped_matches:
                    skipped += int(re.search("\\d+", skipped_matches[len(skipped_matches) - 1]).group())

    return {
        'tests_run': run,
        'tests_fail': fail,
        'tests_error': error,
        'skipped_tests': skipped
    }
