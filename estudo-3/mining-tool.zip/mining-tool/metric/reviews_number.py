import re

bot = "codacy-bot|Codacy|SonarQube analysis"


def compute_rn(gl_notes):
    commits = []

    for gl_note in gl_notes:
        test_bot = re.findall(bot, gl_note.body)

        if not test_bot \
                and not gl_note.system \
                and gl_note.type == 'DiffNote' \
                and gl_note.position['head_sha'] not in commits:
            commits.append(gl_note.position['head_sha'])

    return len(commits)
