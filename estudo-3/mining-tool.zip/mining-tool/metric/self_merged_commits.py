def compute_smc(gl, gl_merge_request, gl_commits):
    merge_user_emails = list(map(lambda e: e.email, gl.users.get(gl_merge_request.merged_by['id']).emails.list()))
    self_merged_commits = 0

    for commit in gl_commits:
        if commit.attributes['committer_email'] in merge_user_emails:
            self_merged_commits += 1

    return self_merged_commits
