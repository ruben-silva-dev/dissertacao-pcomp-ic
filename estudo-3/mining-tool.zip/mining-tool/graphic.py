import matplotlib.pyplot as plt
import pandas as pd
import scipy.stats
import seaborn as sns
from sklearn.preprocessing import MinMaxScaler

csv_columns = {
    "review_time": "M1",
    "average_time_between_comments": "M2",
    "time_between_first_and_last_comment": "M3",
    "participants_number": "M4",
    "inline_comments": "M5",
    "general_comments": "M6",
    "effective_comments": "M7",
    "total_comments": "M8",
    "first_response_time": "M9",
    "mention_number": "M10",
    "self_merged_commits": "M11",
    "source_code_added_lines": "M12",
    "source_code_removed_lines": "M13",
    "test_code_added_lines": "M14",
    "test_code_removed_lines": "M15",
    "reviews_number": "M16",
    "added_files": "M17",
    "deleted_files": "M18",
    "modified_files": "M19",
    "total_changes": "M20",
    "total_builds": "M21",
    "success_builds": "M22",
    "failed_builds": "M23",
    "total_jobs": "M24",
    "success_jobs": "M25",
    "failed_jobs": "M26",
    "tests_run": "M27",
    "tests_fail": "M28",
    "tests_error": "M29",
    "skipped_tests": "M30",
    "ci_latency": "M31",
    "build_correction_intervals": "M32"
}

cr_metrics = [
    csv_columns['review_time'],
    csv_columns['average_time_between_comments'],
    csv_columns['time_between_first_and_last_comment'],
    csv_columns['participants_number'],
    csv_columns['inline_comments'],
    csv_columns['general_comments'],
    csv_columns['effective_comments'],
    csv_columns['total_comments'],
    csv_columns['first_response_time'],
    csv_columns['mention_number'],
    csv_columns['self_merged_commits'],
    csv_columns['source_code_added_lines'],
    csv_columns['source_code_removed_lines'],
    csv_columns['test_code_added_lines'],
    csv_columns['test_code_removed_lines'],
    csv_columns['reviews_number'],
    csv_columns['added_files'],
    csv_columns['deleted_files'],
    csv_columns['modified_files'],
    csv_columns['total_changes']
]

ci_metrics = [
    csv_columns['total_builds'],
    csv_columns['success_builds'],
    csv_columns['failed_builds'],
    csv_columns['total_jobs'],
    csv_columns['success_jobs'],
    csv_columns['failed_jobs'],
    csv_columns['tests_run'],
    csv_columns['tests_fail'],
    csv_columns['tests_error'],
    csv_columns['skipped_tests'],
    csv_columns['ci_latency'],
    csv_columns['build_correction_intervals']
]


def generate_cr_boxplot(prefix, dataset):
    plt.subplots_adjust()

    dataset[cr_metrics].boxplot(rot=85)

    plt.savefig(prefix + "_boxplot_cr.png")


def generate_ci_boxplot(prefix, dataset):
    plt.subplots_adjust()

    dataset[ci_metrics].boxplot(rot=85)

    plt.savefig(prefix + "_boxplot_ci.png")


def generate_histogram(prefix, dataset):
    dataset[cr_metrics + ci_metrics].hist(figsize=(21, 28), layout=(8, 4))
    plt.subplots_adjust()
    plt.savefig(prefix + "_histogram.png")


def generate_correlation(prefix, dataset):
    plt.figure(figsize=(28, 30))
    plt.subplots_adjust(left=.19, bottom=.16)

    sns.set(font_scale=2.5)

    sns.heatmap(dataset.corr(method="spearman", numeric_only=True).loc[cr_metrics, ci_metrics], annot=True,
                cbar=False, cmap=sns.diverging_palette(20, 220, n=10), vmin=-1, vmax=1)

    plt.savefig(prefix + "_correlation.png")


def calculate_statistical_significance(prefix, dataset):
    corr, pvalue = scipy.stats.spearmanr(dataset[ci_metrics + cr_metrics])
    pd.DataFrame(pvalue).to_csv(prefix + "_p_value.csv", header=None, index=None)


if __name__ == '__main__':
    # for p in ['general', '22', '26', '36', '39', '41', '54', '55', '56', '78', '133']:
    p = '36'
    pd_data = pd.read_csv(p + "_without_outliers.csv").rename(columns=csv_columns)
    pd_data = pd_data[cr_metrics + ci_metrics].astype(float)

    scaler = MinMaxScaler(feature_range=(-1, 1))
    pd_data[cr_metrics + ci_metrics] = scaler.fit_transform(
        pd_data[cr_metrics + ci_metrics])

    generate_cr_boxplot(p, pd_data)
    # generate_ci_boxplot(p, pd_data)
    # generate_histogram(p, pd_data)
    # generate_correlation(p, pd_data)
    # calculate_statistical_significance(p, pd_data)
