package com.tool.pipelineApi.model;

public enum Status {
    running, pending, success, failed, canceled, skipped, created, manual
}
