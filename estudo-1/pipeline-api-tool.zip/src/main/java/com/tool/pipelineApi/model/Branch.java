package com.tool.pipelineApi.model;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

@Entity
public class Branch {

    @Id
    private String nome;

    @OneToMany(mappedBy = "branch", cascade = {CascadeType.ALL})
    private List<Pipeline> pipelines;

    public Branch() {
    }

    public Branch(String nome) {
        this.nome = nome;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public List<Pipeline> getPipelines() {
        return pipelines;
    }

    public void setPipelines(List<Pipeline> pipelines) {
        this.pipelines = pipelines;
    }

    public void addPipeline(Pipeline pipeline) {
        if (this.pipelines == null || this.pipelines.isEmpty()) {
            this.pipelines = new ArrayList<>();
        }

        this.pipelines.add(pipeline);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Branch branch = (Branch) o;
        return nome.equals(branch.nome);
    }

    @Override
    public int hashCode() {
        return Objects.hash(nome);
    }
}
