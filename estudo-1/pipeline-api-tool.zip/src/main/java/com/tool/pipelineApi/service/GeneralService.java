package com.tool.pipelineApi.service;

import com.tool.pipelineApi.model.Branch;
import com.tool.pipelineApi.model.Pipeline;
import com.tool.pipelineApi.model.Status;
import com.tool.pipelineApi.repository.BranchRepository;
import com.tool.pipelineApi.repository.PipelineRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Service
public class GeneralService {

    @Autowired
    private BranchRepository branchRepository;

    @Autowired
    private PipelineRepository pipelineRepository;

    public void saveAll(List<Map<String, Object>> mapList) {
        List<Branch> branches = new ArrayList<>();

        for (Map<String, Object> item : mapList
        ) {
            Pipeline pipeline = new Pipeline();
            pipeline.setId((Integer) item.get("id"));
            pipeline.setStatus(Status.valueOf((String) item.get("status")));
            pipeline.setDateTime(LocalDateTime.parse(((String) item.get("updated_at")).substring(0, 22)));

            if (branches.contains(new Branch((String) item.get("ref")))) {
                Branch branch = branches.get(branches.indexOf(new Branch((String) item.get("ref"))));
                pipeline.setBranch(branch);
                branch.addPipeline(pipeline);

            } else {
                Branch branch = new Branch((String) item.get("ref"));
                pipeline.setBranch(branch);
                branch.addPipeline(pipeline);
                branches.add(branch);
            }
        }

        branchRepository.saveAll(branches);
    }
}
