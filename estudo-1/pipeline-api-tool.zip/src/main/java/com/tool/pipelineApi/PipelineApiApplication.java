package com.tool.pipelineApi;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.tool.pipelineApi.model.Branch;
import com.tool.pipelineApi.model.Pipeline;
import com.tool.pipelineApi.model.Status;
import com.tool.pipelineApi.repository.BranchRepository;
import com.tool.pipelineApi.repository.PipelineRepository;
import com.tool.pipelineApi.service.GeneralService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import java.time.Duration;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@SpringBootApplication
public class PipelineApiApplication {

    @Autowired
    private BranchRepository branchRepository;
    @Autowired
    private PipelineRepository pipelineRepository;
    @Autowired
    private GeneralService generalService;

    public static void main(String[] args) {
        SpringApplication.run(PipelineApiApplication.class, args);
    }

    @Bean
    public RestTemplate restTemplate(RestTemplateBuilder builder) {
        return builder.build();

    }

    @Bean
    public HttpEntity<?> httpEntity() {
        HttpHeaders headers = new HttpHeaders();
        headers.setBearerAuth("GITLAB_AUTH_TOKEN");
        return new HttpEntity<>(null, headers);
    }

    @Bean
    public CommandLineRunner run(RestTemplate restTemplate, HttpEntity<?> httpEntity) {
        return args -> {
            String projectId = "PROJECT_ID";
            String updatedAfter = "START_DATETIME";
            String updatedBefore = "END_DATETIME";
            int page = 0;

            ObjectMapper objectMapper = new ObjectMapper();
            List<Map<String, Object>> mapList;
            do {
                ++page;

                ResponseEntity<String> responseEntity = restTemplate.exchange(String.format("GITLAB_SERVER_ADDRESS/api/v4/projects/%s/pipelines?updated_after=%s&updated_before=%s&per_page=100&page=%s",
                        projectId, updatedAfter, updatedBefore, page), HttpMethod.GET, httpEntity, String.class);

                mapList = objectMapper.readValue(responseEntity.getBody(), objectMapper.getTypeFactory().constructCollectionType(List.class, Map.class));
                generalService.saveAll(mapList);
            } while (!mapList.isEmpty());

            List<Branch> branches = branchRepository.findAll();
            List<Duration> durations = new ArrayList<>();

            LocalDateTime startPoint = null;

            for (Branch branch : branches
            ) {
                List<Pipeline> pipelines = pipelineRepository.findByBranchOrderByDateTimeAsc(branch);

                for (Pipeline pipeline : pipelines
                ) {
                    if (pipeline.getStatus().equals(Status.failed) && startPoint == null) {
                        startPoint = pipeline.getDateTime();
                    } else if (pipeline.getStatus().equals(Status.success) && startPoint != null) {
                        durations.add(Duration.between(startPoint, pipeline.getDateTime()));
                        startPoint = null;
                    }
                }

                startPoint = null;
            }

            long totalSeconds = 0;
            long maxTime = Long.MIN_VALUE;
            long minTime = Long.MAX_VALUE;
            for (Duration duration : durations
            ) {
                long seconds = duration.getSeconds();
                long absSeconds = Math.abs(seconds);
                String positive = String.format(
                        "%d days, %d hours, %02d minutes and %02d seconds",
                        absSeconds / 86400,
                        (absSeconds % 86400) / 3600,
                        (absSeconds % 3600) / 60,
                        absSeconds % 60);
                System.out.println(seconds < 0 ? "-" + positive : positive);

                totalSeconds += seconds;
                if (seconds < minTime) minTime = seconds;
                if (seconds > maxTime) maxTime = seconds;
            }

            long average = totalSeconds / durations.size();
            String averageString = String.format(
                    "%d days, %d hours, %02d minutes and %02d seconds",
                    average / 86400,
                    (average % 86400) / 3600,
                    (average % 3600) / 60,
                    average % 60);
            System.out.println("Average time: " + averageString);

            String maxTimeString = String.format(
                    "%d days, %d hours, %02d minutes and %02d seconds",
                    maxTime / 86400,
                    (maxTime % 86400) / 3600,
                    (maxTime % 3600) / 60,
                    maxTime % 60);
            System.out.println("Longer time: " + maxTimeString);

            String minTimeString = String.format(
                    "%d days, %d hours, %02d minutes and %02d seconds",
                    minTime / 86400,
                    (minTime % 86400) / 3600,
                    (minTime % 3600) / 60,
                    minTime % 60);
            System.out.println("Shorter time: " + minTimeString);
        };
    }
}
