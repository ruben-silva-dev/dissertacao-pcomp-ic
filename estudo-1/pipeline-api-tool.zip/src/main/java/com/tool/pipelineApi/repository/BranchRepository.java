package com.tool.pipelineApi.repository;

import com.tool.pipelineApi.model.Branch;
import org.springframework.data.jpa.repository.JpaRepository;

public interface BranchRepository extends JpaRepository<Branch, String> {
}
