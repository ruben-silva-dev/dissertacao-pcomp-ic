package com.tool.pipelineApi.repository;

import com.tool.pipelineApi.model.Branch;
import com.tool.pipelineApi.model.Pipeline;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface PipelineRepository extends JpaRepository<Pipeline, Integer> {
    List<Pipeline> findByBranchOrderByDateTimeAsc(Branch branch);
}
